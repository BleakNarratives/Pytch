def check_claim(claim):
    # Simple keyword check (placeholder)
    keywords = ["fake", "scam", "misleading"]
    for word in keywords:
        if word in claim.lower():
            return "Potential misinformation detected."
    return "Claim appears neutral."

if __name__ == "__main__":
    claim = input("Enter a statement for verification: ")
    print(check_claim(claim))
